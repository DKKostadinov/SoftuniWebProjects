﻿namespace AspNetCoreTemplate.Web.ViewModels.Administration.Dashboard
{
    public class IndexViewModel
    {
        public int SettingsCount { get; set; }
    }
}
