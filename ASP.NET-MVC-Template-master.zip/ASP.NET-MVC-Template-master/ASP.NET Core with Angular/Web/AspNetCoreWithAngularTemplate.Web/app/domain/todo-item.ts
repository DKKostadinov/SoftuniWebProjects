﻿export class TodoItem {
    public id: number;

    public title: string;

    public isDone: boolean;
}
